.extern int *protector;
